<?php

namespace App\Notifications;

use App\Models\Trip;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class TripOfferCreated extends Notification
{
    use Queueable;

    public $trip;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(Trip $trip)
    {
        $this->trip = $trip;

    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('The introduction to the notification.')
            ->action('Notification Action', url('/'))
            ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'trip_id' => $this->trip->id,
            'text' => __('trips.new_trip_offer'),
            'show_url' => route('trips.show', $this->trip->id),
            'image' => $this->trip->shipment->truckType->image_path,
            'provider' => $this->trip->provider->name,
            'client_price' => $this->trip->client_price,
            'loading_location' => $this->trip->shipment->loading_location,
            'drop_off_location' => $this->trip->shipment->drop_off_location,
            'route' => $this->trip->shipment->route ? $this->trip->shipment->route->name : null,
        ];
    }
}
